const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const player = {
  x: canvas.width / 2,
  y: canvas.height / 2,
  w: 30,
  h: 40,
  speed: 4,
  dx: 0,
  dy: 0,
  angle: 0,
  hp: 50,
  maxHp: 50,
  fireRate: 400,
  invincible: 0
};

let bullets = [],
  zombies = [],
  score = 0,
  gameOver = false;
let touch1 = null,
  touch2 = null;
let boss = null,
  bossActive = false,
  bossSpawned = false;
let showBossDefeated = false,
  bossDefeatedTimer = 0;
let wave = 1,
  showWave2 = false,
  wave2Timer = 0,
  wave2Started = false;
let showSkillSelect = false;
let time = 0;
let fireInterval = null;

function startFireInterval() {
  if (fireInterval) clearInterval(fireInterval);
  fireInterval = setInterval(() => {
    if (!gameOver && touch2 && !showSkillSelect && !showBossDefeated && !showWave2) {
      bullets.push({
        x: player.x + 15,
        y: player.y + 20,
        dx: Math.cos(player.angle) * 10,
        dy: Math.sin(player.angle) * 10
      });
    }
  }, player.fireRate);
}
startFireInterval();

setInterval(() => {
  if (!gameOver && !bossActive && !showBossDefeated && !showWave2 && !showSkillSelect) {
    spawnZombie();
  }
}, wave2Started ? 800 : 1200);

setInterval(() => {
  if (!gameOver && bossActive && boss) {
    const dx = player.x - boss.x,
      dy = player.y - boss.y;
    const angle = Math.atan2(dy, dx);
    for (let i = -1; i <= 1; i++) {
      const a = angle + i * 0.3;
      boss.bullets.push({ x: boss.x, y: boss.y, dx: Math.cos(a) * 5, dy: Math.sin(a) * 5 });
    }
  }
}, 1500);

canvas.addEventListener('touchstart', e => {
  e.preventDefault();
  // Klik skill
  if (showSkillSelect) {
    const t = e.touches[0];
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const skills = [
      { y: cy - 60 }, { y: cy + 20 }, { y: cy + 100 }
    ];
    skills.forEach((s, i) => {
      if (t.clientX > cx - 160 && t.clientX < cx + 160 &&
        t.clientY > s.y - 30 && t.clientY < s.y + 30) {
        selectSkill(i + 1);
      }
    });
    return;
  }
  for (let t of e.changedTouches) {
    if (!touch1) touch1 = { id: t.identifier, startX: t.clientX, startY: t.clientY, x: t.clientX, y: t.clientY };
    else if (!touch2) touch2 = { id: t.identifier, startX: t.clientX, startY: t.clientY, x: t.clientX, y: t.clientY };
  }
}, { passive: false });

canvas.addEventListener('touchmove', e => {
  e.preventDefault();
  for (let t of e.changedTouches) {
    if (touch1 && t.identifier === touch1.id) { touch1.x = t.clientX;
      touch1.y = t.clientY; }
    if (touch2 && t.identifier === touch2.id) {
      touch2.x = t.clientX;
      touch2.y = t.clientY;
      const dx = touch2.x - touch2.startX,
        dy = touch2.y - touch2.startY;
      if (Math.sqrt(dx * dx + dy * dy) > 10) player.angle = Math.atan2(dy, dx);
    }
  }
}, { passive: false });

canvas.addEventListener('touchend', e => {
  e.preventDefault();
  for (let t of e.changedTouches) {
    if (touch1 && t.identifier === touch1.id) { touch1 = null;
      player.dx = 0;
      player.dy = 0; }
    if (touch2 && t.identifier === touch2.id) touch2 = null;
  }
}, { passive: false });

function selectSkill(n) {
  if (n === 1) { player.maxHp = 150;
    player.hp = 150; }
  else if (n === 2) { player.fireRate = 180;
    startFireInterval(); }
  else if (n === 3) { player.speed = 7; }
  showSkillSelect = false;
  showWave2 = true;
  wave2Timer = 0;
}

function spawnZombie() {
  const side = Math.floor(Math.random() * 4);
  let x, y;
  if (side === 0) { x = Math.random() * canvas.width;
    y = -40; }
  else if (side === 1) { x = canvas.width + 40;
    y = Math.random() * canvas.height; }
  else if (side === 2) { x = Math.random() * canvas.width;
    y = canvas.height + 40; }
  else { x = -40;
    y = Math.random() * canvas.height; }
  zombies.push({ x, y, speed: (wave === 2 ? 2.5 : 1.5) + score * 0.01 });
}

function spawnBoss() {
  bossActive = true;
  bossSpawned = true;
  zombies = [];
  boss = { x: canvas.width / 2, y: -80, hp: 30, maxHp: 30, speed: 1.2, bullets: [], shake: 0 };
}

function takeDamage(dmg) {
  if (player.invincible > 0) return;
  player.hp -= dmg;
  player.invincible = 60;
  if (player.hp <= 0) { player.hp = 0;
    gameOver = true; }
}

function update() {
  if (gameOver || showSkillSelect) return;
  time++;
  
  if (score >= 50 && !bossSpawned) spawnBoss();
  if (player.invincible > 0) player.invincible--;
  
  if (showBossDefeated) {
    bossDefeatedTimer++;
    if (bossDefeatedTimer > 180) { showBossDefeated = false;
      showSkillSelect = true; }
    return;
  }
  
  if (showWave2) {
    wave2Timer++;
    if (wave2Timer > 150) { showWave2 = false;
      wave = 2;
      wave2Started = true; }
    return;
  }
  
  if (touch1) {
    const dx = touch1.x - touch1.startX,
      dy = touch1.y - touch1.startY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > 10) { player.dx = (dx / dist) * player.speed;
      player.dy = (dy / dist) * player.speed; }
    else { player.dx = 0;
      player.dy = 0; }
  }
  
  player.x += player.dx;
  player.y += player.dy;
  player.x = Math.max(0, Math.min(canvas.width - player.w, player.x));
  player.y = Math.max(0, Math.min(canvas.height - player.h, player.y));
  
  bullets = bullets.filter(b => b.x > -10 && b.x < canvas.width + 10 && b.y > -10 && b.y < canvas.height + 10);
  bullets.forEach(b => { b.x += b.dx;
    b.y += b.dy; });
  
  if (!bossActive) {
    zombies.forEach(z => {
      const dx = player.x - z.x,
        dy = player.y - z.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      z.x += (dx / dist) * z.speed;
      z.y += (dy / dist) * z.speed;
    });
    
    zombies = zombies.filter(z => {
      for (let i = 0; i < bullets.length; i++) {
        if (Math.abs(bullets[i].x - z.x) < 25 && Math.abs(bullets[i].y - z.y) < 25) {
          bullets.splice(i, 1);
          score++;
          return false;
        }
      }
      return true;
    });
    
    zombies.forEach(z => {
      if (Math.abs(z.x - player.x) < 25 && Math.abs(z.y - player.y) < 25) takeDamage(2);
    });
  }
  
  if (bossActive && boss) {
    const dx = player.x - boss.x,
      dy = player.y - boss.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    boss.x += (dx / dist) * boss.speed;
    boss.y += (dy / dist) * boss.speed;
    if (boss.shake > 0) boss.shake--;
    
    bullets = bullets.filter(b => {
      if (Math.abs(b.x - boss.x) < 40 && Math.abs(b.y - boss.y) < 40) {
        boss.hp--;
        boss.shake = 5;
        if (boss.hp <= 0) {
          bossActive = false;
          boss = null;
          score += 20;
          showBossDefeated = true;
          bossDefeatedTimer = 0;
        }
        return false;
      }
      return true;
    });
    
    if (boss) {
      boss.bullets = boss.bullets.filter(b => b.x > -10 && b.x < canvas.width + 10 && b.y > -10 && b.y < canvas.height + 10);
      boss.bullets.forEach(b => { b.x += b.dx;
        b.y += b.dy; });
      boss.bullets.forEach(b => {
        if (Math.abs(b.x - player.x) < 20 && Math.abs(b.y - player.y) < 20) takeDamage(6);
      });
      if (Math.abs(boss.x - player.x) < 45 && Math.abs(boss.y - player.y) < 45) takeDamage(6);
    }
  }
}

function drawWaveText(text, cx, cy, size, color, amp, t) {
  ctx.font = 'bold ' + size + 'px Arial';
  ctx.textAlign = 'center';
  const letters = text.split('');
  const totalW = ctx.measureText(text).width;
  let startX = cx - totalW / 2;
  letters.forEach((ch, i) => {
    const oy = Math.sin(t * 0.08 + i * 0.5) * amp;
    ctx.fillStyle = color;
    ctx.fillText(ch, startX + ctx.measureText(ch).width / 2, cy + oy);
    startX += ctx.measureText(ch).width;
  });
}

function drawHpBar() {
  const bw = 200,
    bh = 16;
  const bx = 15,
    by = 45;
  ctx.fillStyle = '#333';
  ctx.fillRect(bx, by, bw, bh);
  const pct = player.hp / player.maxHp;
  ctx.fillStyle = pct > 0.5 ? '#2ecc71' : pct > 0.25 ? '#f39c12' : '#e74c3c';
  ctx.fillRect(bx, by, bw * pct, bh);
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 1;
  ctx.strokeRect(bx, by, bw, bh);
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 12px Arial';
  ctx.textAlign = 'left';
  ctx.fillText('HP: ' + player.hp + '/' + player.maxHp, bx + 5, by + 12);
}

function drawHealthBar(x, y, w, hp, maxHp, color) {
  ctx.fillStyle = '#333';
  ctx.fillRect(x, y, w, 12);
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w * (hp / maxHp), 12);
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 1;
  ctx.strokeRect(x, y, w, 12);
}

function drawSkillSelect() {
  ctx.fillStyle = 'rgba(0,0,0,0.88)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#FFD700';
  ctx.font = 'bold 28px Arial';
  ctx.textAlign = 'center';
  ctx.fillText('CHOOSE YOUR SKILL', canvas.width / 2, canvas.height / 2 - 130);
  
  const skills = [
    { label: '❤️  +HP to 150', color: '#e74c3c' },
    { label: '⚡  Faster Shooting', color: '#f39c12' },
    { label: '💨  Faster Movement', color: '#3498db' }
  ];
  
  const cx = canvas.width / 2,
    cy = canvas.height / 2;
  skills.forEach((s, i) => {
    const y = cy - 60 + i * 80;
    ctx.fillStyle = s.color;
    ctx.beginPath();
    ctx.roundRect(cx - 160, y - 30, 320, 55, 12);
    ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 20px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(s.label, cx, y + 8);
  });
}

function draw() {
  ctx.fillStyle = '#111';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  ctx.strokeStyle = '#1a1a1a';
  ctx.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 50) { ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke(); }
  for (let y = 0; y < canvas.height; y += 50) { ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke(); }
  
  if (showBossDefeated) {
    ctx.fillStyle = 'rgba(0,0,0,0.75)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.globalAlpha = Math.min(1, bossDefeatedTimer / 30);
    drawWaveText("What??", canvas.width / 2, canvas.height / 2 - 60, 38, '#ff0', 6, bossDefeatedTimer);
    drawWaveText("You defeated him?", canvas.width / 2, canvas.height / 2, 30, '#fff', 5, bossDefeatedTimer + 10);
    drawWaveText("I can't believe it...", canvas.width / 2, canvas.height / 2 + 55, 26, '#aaa', 4, bossDefeatedTimer + 20);
    ctx.globalAlpha = 1;
    return;
  }
  
  if (showSkillSelect) { drawSkillSelect(); return; }
  
  if (showWave2) {
    ctx.fillStyle = 'rgba(0,0,0,0.85)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.globalAlpha = Math.min(1, wave2Timer / 30);
    const pulse = 1 + Math.sin(wave2Timer * 0.1) * 0.05;
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(pulse, pulse);
    ctx.translate(-canvas.width / 2, -canvas.height / 2);
    drawWaveText("ZOMBIE WAVE 2", canvas.width / 2, canvas.height / 2 - 20, 42, '#f00', 7, wave2Timer);
    ctx.restore();
    ctx.fillStyle = '#ff0';
    ctx.font = '18px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('They are faster and angrier!', canvas.width / 2, canvas.height / 2 + 40);
    ctx.globalAlpha = 1;
    return;
  }
  
  // Joystick
  if (touch1) {
    ctx.strokeStyle = 'rgba(255,255,255,0.15)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(touch1.startX, touch1.startY, 45, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    ctx.beginPath();
    ctx.arc(touch1.x, touch1.y, 22, 0, Math.PI * 2);
    ctx.fill();
  }
  if (touch2) {
    ctx.strokeStyle = 'rgba(255,100,100,0.2)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(touch2.startX, touch2.startY, 45, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,100,100,0.3)';
    ctx.beginPath();
    ctx.arc(touch2.x, touch2.y, 22, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // Player (kedip kalau invincible)
  if (player.invincible === 0 || Math.floor(time / 5) % 2 === 0) {
    ctx.fillStyle = '#FFCC80';
    ctx.fillRect(player.x + 5, player.y, 20, 18);
    ctx.fillStyle = '#2196F3';
    ctx.fillRect(player.x, player.y + 18, 30, 22);
    ctx.save();
    ctx.translate(player.x + 15, player.y + 25);
    ctx.rotate(player.angle);
    ctx.fillStyle = '#888';
    ctx.fillRect(0, -4, 20, 8);
    ctx.restore();
  }
  
  // Peluru
  ctx.fillStyle = '#FFD700';
  bullets.forEach(b => { ctx.beginPath();
    ctx.arc(b.x, b.y, 4, 0, Math.PI * 2);
    ctx.fill(); });
  
  // Zombie
  zombies.forEach(z => {
    ctx.fillStyle = wave === 2 ? '#ff6666' : '#A5D6A7';
    ctx.fillRect(z.x, z.y, 24, 18);
    ctx.fillStyle = wave === 2 ? '#cc0000' : '#4CAF50';
    ctx.fillRect(z.x - 3, z.y + 18, 30, 22);
    ctx.fillStyle = '#f00';
    ctx.fillRect(z.x + 3, z.y + 5, 5, 5);
    ctx.fillRect(z.x + 14, z.y + 5, 5, 5);
  });
  
  // Boss
  if (bossActive && boss) {
    const bx = boss.x + (boss.shake > 0 ? (Math.random() - 0.5) * 10 : 0);
    const by = boss.y + (boss.shake > 0 ? (Math.random() - 0.5) * 10 : 0);
    ctx.fillStyle = '#8B0000';
    ctx.fillRect(bx - 40, by - 40, 80, 80);
    ctx.fillStyle = '#c0392b';
    ctx.fillRect(bx - 25, by - 60, 50, 30);
    ctx.fillStyle = '#ff0';
    ctx.fillRect(bx - 18, by - 52, 10, 10);
    ctx.fillRect(bx + 8, by - 52, 10, 10);
    ctx.fillStyle = '#555';
    ctx.fillRect(bx - 22, by - 75, 8, 20);
    ctx.fillRect(bx + 14, by - 75, 8, 20);
    ctx.fillStyle = '#ff0';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('BOSS', bx, by - 80);
    drawHealthBar(canvas.width / 2 - 100, 50, 200, boss.hp, boss.maxHp, '#e74c3c');
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('BOSS HP: ' + boss.hp + '/' + boss.maxHp, canvas.width / 2, 48);
    ctx.fillStyle = '#ff4500';
    boss.bullets.forEach(b => { ctx.beginPath();
      ctx.arc(b.x, b.y, 7, 0, Math.PI * 2);
      ctx.fill(); });
  }
  
  // UI
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 20px Arial';
  ctx.textAlign = 'left';
  ctx.fillText('Score: ' + score, 15, 35);
  drawHpBar();
  if (wave === 2) { ctx.fillStyle = '#f00';
    ctx.font = 'bold 14px Arial';
    ctx.fillText('WAVE 2', 15, 80); }
  
  if (score >= 45 && score < 50 && !bossSpawned) {
    ctx.fillStyle = 'rgba(255,0,0,0.1)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#f00';
    ctx.font = 'bold 20px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('WARNING: BOSS IS COMING!', canvas.width / 2, canvas.height / 2);
  }
  
  if (gameOver) {
    ctx.fillStyle = 'rgba(0,0,0,0.8)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#f00';
    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('GAME OVER', canvas.width / 2, canvas.height / 2 - 30);
    ctx.fillStyle = '#fff';
    ctx.font = '22px Arial';
    ctx.fillText('Score: ' + score, canvas.width / 2, canvas.height / 2 + 20);
    ctx.fillStyle = '#0f0';
    ctx.font = '16px Arial';
    ctx.fillText('Refresh to play again', canvas.width / 2, canvas.height / 2 + 60);
  }
}

function loop() { update();
  draw();
  time++;
  requestAnimationFrame(loop); }
loop();